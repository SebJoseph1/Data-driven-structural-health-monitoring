// This file defines the conversion between human readable names to values used by the arduino

#include "pins_arduino.h"
#define PORTRAIT 0
#define LANDSCAPE 1
#define PORTRAIT_REVERSE 2
#define LANDSCAPE_REVERSE 3

#define INPUT_DIFFRENTIAL_0_1 1
#define INPUT_TYPE_SINGLE_ENDED_2 2
#define INPUT_TYPE_SINGLE_ENDED_3 3

#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

const int XP=6,XM=A2,YP=A1,YM=7; //ID=0x9341
const int TS_LEFT=942,TS_RT=206,TS_TOP=910,TS_BOT=172;
//const int TS_LEFT=907,TS_RT=136,TS_TOP=942,TS_BOT=139;

#define TOUCH_MIN_PRESSURE 200
#define TOUCH_MAX_PRESSURE 1000

#define ADC_HISTORY_SAMPLES 100
